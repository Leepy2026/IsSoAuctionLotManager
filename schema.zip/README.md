# Simple Auction Lot Manager
Built with ASP.NET Core Blazor Server, C# and in-memory storage

# Design?
Used in-memory storage so the project is quick to run, easy to review, and does not require a datbase for quick accessment of 
coding style ( normally I would use Entity Framework ) 

# Features implemented
- List all auction lots
- Add a new lot
- Edit a lot
- Delete a lot
- Client-side and server-side validation
- Search bar
- Active-only filter
- Pagination
- Live countdown timer for lot close time

# Tech stack
- .NET 8
- ASP.NET Core Blazor Server
- C#
- In-memory singleton service
- CSS styling with Bootstrap-compatible layout

# Project structure
- Models – domain and form models
- Services – in-memory CRUD logic
- Pages – Blazor pages for list/create/edit
- Tests – sample unit tests for the service layer

# Setup instructions
Uses .NET 8 SDK. ( should be ready to go )
-- bash dotnet restore dotnet run
Hit the Play button

# Architecture decisions
- Blazor Server was chosen to keep the stack fully in C# and for speed of producing it
- Service abstraction (IAuctionLotService) keeps business logic separate from UI.
- Used in-memory service ( as per  brief ).


# Misc
- Countdown timer: implemented with a reusable Blazor component that updates every second.
- Search/filter: supports free-text search and active-only filtering.
- Pagination: implemented on the main lot listing.


# Improvments
- Use Entity framework
- Add full end-to-end test coverage
- Add sorting on table columns
- Add richer auction workflows such as bid history and lot images
- Add SignalR 
- Add authentication and role-based permissions
- Add images section to each auction lot
- Multi language for on screen text
- Connect to Database with Stored Procedures 



